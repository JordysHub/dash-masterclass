'''
Oefening 1.1:
Gebruikt een Dash Html Component om in de app layout "Hello, Best Talent Group Ever!" te plaatsen.
'''

from dash import Dash, html, dcc

app = Dash(__name__)





FILL_IN = ######
app.layout = html.Div([FILL_IN])






if __name__ == "__main__":
    app.run_server(debug=True)


